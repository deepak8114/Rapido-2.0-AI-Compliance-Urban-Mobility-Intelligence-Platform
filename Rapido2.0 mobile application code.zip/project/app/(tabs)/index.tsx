import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, TextInput, Alert } from 'react-native';
import { MapPin, Mic, Search, Clock, Star, Navigation, Armchair as Wheelchair, Phone } from 'lucide-react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { router } from 'expo-router';
import * as Speech from 'expo-speech';
import * as Location from 'expo-location';

const rideTypes = [
  { id: 'bike', name: 'Bike', price: '₹45', time: '3 min', icon: '🏍️' },
  { id: 'auto', name: 'Auto', price: '₹65', time: '5 min', icon: '🛺' },
  { id: 'car', name: 'Car', price: '₹120', time: '8 min', icon: '🚗' },
];

const quickDestinations = [
  { name: 'Home', address: 'Koramangala, Bangalore', icon: '🏠' },
  { name: 'Office', address: 'Electronic City, Bangalore', icon: '🏢' },
  { name: 'Airport', address: 'Kempegowda International Airport', icon: '✈️' },
];

export default function HomeScreen() {
  const [userRole, setUserRole] = useState('regular');
  const [currentLocation, setCurrentLocation] = useState('Fetching location...');
  const [destination, setDestination] = useState('');
  const [isListening, setIsListening] = useState(false);

  useEffect(() => {
    const getUserData = async () => {
      const role = await AsyncStorage.getItem('userRole');
      if (role) setUserRole(role);
    };
    getUserData();
    getCurrentLocation();
  }, []);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setCurrentLocation('Location permission denied');
        return;
      }

      const location = await Location.getCurrentPositionAsync({});
      const address = await Location.reverseGeocodeAsync({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      });

      if (address[0]) {
        setCurrentLocation(`${address[0].street}, ${address[0].city}`);
      }
    } catch (error) {
      setCurrentLocation('Unable to fetch location');
    }
  };

  const isPwdMode = userRole === 'pwd';
  const isDriver = userRole === 'driver';

  const handleVoiceInput = () => {
    setIsListening(true);
    Speech.speak('Please say your destination', {
      onDone: () => {
        setIsListening(false);
        // In a real app, you'd implement speech-to-text here
        Alert.alert('Voice Input', 'Voice input feature will be implemented with speech-to-text API');
      },
    });
  };

  const bookRide = (rideType: any) => {
    if (!destination.trim()) {
      Alert.alert('Error', 'Please enter a destination');
      return;
    }
    
    router.push({
      pathname: '/booking',
      params: { 
        rideType: rideType.id,
        destination,
        userRole 
      }
    });
  };

  if (isDriver) {
    return (
      <ScrollView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.greeting}>Good morning, Driver!</Text>
          <View style={styles.statusBadge}>
            <Text style={styles.statusText}>🟢 Online</Text>
          </View>
        </View>

        <View style={styles.driverStats}>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>₹1,250</Text>
            <Text style={styles.statLabel}>Today's Earnings</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>12</Text>
            <Text style={styles.statLabel}>Trips Completed</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statValue}>4.8</Text>
            <Text style={styles.statLabel}>Rating</Text>
          </View>
        </View>

        <View style={styles.complianceCard}>
          <Text style={styles.cardTitle}>Compliance Status</Text>
          <View style={styles.complianceItem}>
            <Text style={styles.complianceText}>✅ Documents Verified</Text>
          </View>
          <View style={styles.complianceItem}>
            <Text style={styles.complianceText}>✅ Training Completed</Text>
          </View>
          <View style={styles.complianceItem}>
            <Text style={styles.complianceText}>⚠️ Daily Limit: 7/9 hours</Text>
          </View>
        </View>

        <TouchableOpacity style={styles.primaryButton}>
          <Text style={styles.primaryButtonText}>Go Online</Text>
        </TouchableOpacity>
      </ScrollView>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={[styles.greeting, isPwdMode && styles.largeText]}>
          {isPwdMode ? 'Welcome to Accessible Rapido' : 'Where to go?'}
        </Text>
        <TouchableOpacity 
          style={styles.voiceButton}
          onPress={handleVoiceInput}
        >
          <Mic color={isListening ? "#00B8F1" : "#002B5B"} size={isPwdMode ? 28 : 24} />
        </TouchableOpacity>
      </View>

      <View style={styles.locationCard}>
        <View style={styles.locationRow}>
          <MapPin color="#00B8F1" size={20} />
          <Text style={[styles.locationText, isPwdMode && styles.largeText]}>
            {currentLocation}
          </Text>
        </View>
      </View>

      <View style={styles.searchContainer}>
        <Search color="#666666" size={20} />
        <TextInput
          style={[styles.searchInput, isPwdMode && styles.largeInput]}
          placeholder="Where do you want to go?"
          placeholderTextColor="#999999"
          value={destination}
          onChangeText={setDestination}
          accessibilityLabel="Destination input"
          accessibilityHint="Enter your destination address"
        />
        {isPwdMode && (
          <TouchableOpacity onPress={handleVoiceInput}>
            <Mic color="#002B5B" size={24} />
          </TouchableOpacity>
        )}
      </View>

      <View style={styles.quickDestinations}>
        <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
          Quick Destinations
        </Text>
        {quickDestinations.map((dest, index) => (
          <TouchableOpacity 
            key={index}
            style={styles.destinationCard}
            onPress={() => setDestination(dest.address)}
          >
            <Text style={styles.destinationIcon}>{dest.icon}</Text>
            <View style={styles.destinationInfo}>
              <Text style={[styles.destinationName, isPwdMode && styles.largeText]}>
                {dest.name}
              </Text>
              <Text style={[styles.destinationAddress, isPwdMode && styles.mediumText]}>
                {dest.address}
              </Text>
            </View>
            <Clock color="#666666" size={16} />
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.rideTypes}>
        <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
          Choose Ride Type
        </Text>
        {rideTypes.map((ride) => (
          <TouchableOpacity 
            key={ride.id}
            style={[styles.rideCard, isPwdMode && styles.largeRideCard]}
            onPress={() => bookRide(ride)}
          >
            <Text style={styles.rideIcon}>{ride.icon}</Text>
            <View style={styles.rideInfo}>
              <Text style={[styles.rideName, isPwdMode && styles.largeText]}>
                {ride.name}
              </Text>
              <Text style={[styles.rideDetails, isPwdMode && styles.mediumText]}>
                {ride.time} • {ride.price}
              </Text>
            </View>
            <View style={styles.rideRating}>
              <Star color="#FFD700" size={16} fill="#FFD700" />
              <Text style={styles.ratingText}>4.8</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      {isPwdMode && (
        <View style={styles.accessibilityCard}>
          <Text style={[styles.cardTitle, styles.largeText]}>
            Accessibility Options
          </Text>
          <TouchableOpacity style={styles.accessibilityOption}>
            <Wheelchair color="#002B5B" size={24} />
            <Text style={[styles.accessibilityText, styles.largeText]}>
              Request wheelchair accessible vehicle
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.accessibilityOption}>
            <Phone color="#002B5B" size={24} />
            <Text style={[styles.accessibilityText, styles.largeText]}>
              Driver will call before pickup
            </Text>
          </TouchableOpacity>
        </View>
      )}

      <TouchableOpacity 
        style={[styles.bookRideButton, isPwdMode && styles.largeBookRideButton]}
        onPress={() => destination.trim() && bookRide(rideTypes[0])}
      >
        <Text style={[styles.bookRideButtonText, isPwdMode && styles.largeButtonText]}>
          Book Ride Now
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    paddingTop: 60,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  greeting: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    color: '#002B5B',
    flex: 1,
  },
  largeText: {
    fontSize: 20,
  },
  mediumText: {
    fontSize: 16,
  },
  voiceButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#E8F4FD',
    alignItems: 'center',
    justifyContent: 'center',
  },
  statusBadge: {
    backgroundColor: '#E8F5E8',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  statusText: {
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
    color: '#2E7D32',
  },
  locationCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationText: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    color: '#333333',
    marginLeft: 12,
    flex: 1,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    borderRadius: 12,
    paddingHorizontal: 16,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  searchInput: {
    flex: 1,
    paddingVertical: 16,
    paddingLeft: 12,
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#333333',
  },
  largeInput: {
    fontSize: 18,
    paddingVertical: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: '#002B5B',
    marginBottom: 12,
  },
  quickDestinations: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  destinationCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  destinationIcon: {
    fontSize: 24,
    marginRight: 16,
  },
  destinationInfo: {
    flex: 1,
  },
  destinationName: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#333333',
    marginBottom: 4,
  },
  destinationAddress: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
  },
  rideTypes: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  rideCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  largeRideCard: {
    padding: 20,
  },
  rideIcon: {
    fontSize: 32,
    marginRight: 16,
  },
  rideInfo: {
    flex: 1,
  },
  rideName: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: '#333333',
    marginBottom: 4,
  },
  rideDetails: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
  },
  rideRating: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
    color: '#333333',
    marginLeft: 4,
  },
  driverStats: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    marginBottom: 24,
    gap: 12,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  statValue: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    color: '#002B5B',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
    textAlign: 'center',
  },
  complianceCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  cardTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: '#002B5B',
    marginBottom: 12,
  },
  complianceItem: {
    marginBottom: 8,
  },
  complianceText: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#333333',
  },
  accessibilityCard: {
    backgroundColor: '#E8F4FD',
    marginHorizontal: 20,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    borderWidth: 2,
    borderColor: '#00B8F1',
  },
  accessibilityOption: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  accessibilityText: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    color: '#002B5B',
    marginLeft: 12,
    flex: 1,
  },
  primaryButton: {
    backgroundColor: '#00B8F1',
    marginHorizontal: 20,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#00B8F1',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  primaryButtonText: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
  },
  bookRideButton: {
    backgroundColor: '#002B5B',
    marginHorizontal: 20,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginBottom: 40,
    shadowColor: '#002B5B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  largeBookRideButton: {
    paddingVertical: 20,
  },
  bookRideButtonText: {
    fontSize: 18,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
  },
  largeButtonText: {
    fontSize: 20,
  },
});