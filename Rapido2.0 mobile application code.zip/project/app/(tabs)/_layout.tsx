import React, { useEffect, useState } from 'react';
import { Tabs } from 'expo-router';
import { Chrome as Home, MapPin, MessageCircle, User, Shield } from 'lucide-react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function TabLayout() {
  const [userRole, setUserRole] = useState('regular');

  useEffect(() => {
    const getUserRole = async () => {
      const role = await AsyncStorage.getItem('userRole');
      if (role) setUserRole(role);
    };
    getUserRole();
  }, []);

  const isPwdMode = userRole === 'pwd';
  const isDriver = userRole === 'driver';

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: '#FFFFFF',
          borderTopWidth: 1,
          borderTopColor: '#E5E5E5',
          height: isPwdMode ? 80 : 60,
          paddingBottom: isPwdMode ? 20 : 8,
          paddingTop: isPwdMode ? 16 : 8,
        },
        tabBarLabelStyle: {
          fontSize: isPwdMode ? 14 : 12,
          fontFamily: 'Poppins-Medium',
          marginTop: 4,
        },
        tabBarActiveTintColor: '#002B5B',
        tabBarInactiveTintColor: '#999999',
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Home',
          tabBarIcon: ({ size, color }) => (
            <Home size={isPwdMode ? size + 4 : size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="rides"
        options={{
          title: isDriver ? 'Trips' : 'My Rides',
          tabBarIcon: ({ size, color }) => (
            <MapPin size={isPwdMode ? size + 4 : size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="support"
        options={{
          title: 'Support',
          tabBarIcon: ({ size, color }) => (
            <MessageCircle size={isPwdMode ? size + 4 : size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="safety"
        options={{
          title: 'Safety',
          tabBarIcon: ({ size, color }) => (
            <Shield size={isPwdMode ? size + 4 : size} color={color} />
          ),
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Profile',
          tabBarIcon: ({ size, color }) => (
            <User size={isPwdMode ? size + 4 : size} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}