import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput } from 'react-native';
import { MessageCircle, Phone, Mail, CircleHelp as HelpCircle, TriangleAlert as AlertTriangle, Mic, Send } from 'lucide-react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const supportCategories = [
  { id: 'ride', title: 'Ride Issues', icon: '🚗', description: 'Problems with your ride' },
  { id: 'payment', title: 'Payment & Billing', icon: '💳', description: 'Payment related queries' },
  { id: 'account', title: 'Account Settings', icon: '👤', description: 'Profile and account help' },
  { id: 'accessibility', title: 'Accessibility', icon: '♿', description: 'Accessibility features help' },
  { id: 'safety', title: 'Safety Concerns', icon: '🛡️', description: 'Report safety issues' },
  { id: 'other', title: 'Other Issues', icon: '❓', description: 'General support' },
];

const faqItems = [
  {
    question: 'How do I cancel a ride?',
    answer: 'You can cancel a ride from the ride tracking screen by tapping the "Cancel Ride" button. Cancellation charges may apply based on timing.'
  },
  {
    question: 'What if my driver doesn\'t arrive?',
    answer: 'If your driver doesn\'t arrive within the estimated time, you can contact them directly or report the issue through our support system.'
  },
  {
    question: 'How do I enable accessibility features?',
    answer: 'Go to Profile > Accessibility Settings to enable features like voice commands, high contrast mode, and driver assistance requests.'
  },
  {
    question: 'What payment methods are accepted?',
    answer: 'We accept cash, UPI, credit/debit cards, and digital wallets. You can manage payment methods in your profile.'
  },
];

export default function SupportScreen() {
  const [userRole, setUserRole] = useState('regular');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [message, setMessage] = useState('');
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  useEffect(() => {
    const getUserRole = async () => {
      const role = await AsyncStorage.getItem('userRole');
      if (role) setUserRole(role);
    };
    getUserRole();
  }, []);

  const isPwdMode = userRole === 'pwd';

  const handleSendMessage = () => {
    if (message.trim() && selectedCategory) {
      // Handle message sending logic here
      console.log('Sending message:', { category: selectedCategory, message });
      setMessage('');
      setSelectedCategory('');
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={[styles.title, isPwdMode && styles.largeText]}>
          Support & Help
        </Text>
        <Text style={[styles.subtitle, isPwdMode && styles.mediumText]}>
          We're here to help you 24/7
        </Text>
      </View>

      {/* Emergency Contact */}
      <View style={[styles.emergencyCard, isPwdMode && styles.largeEmergencyCard]}>
        <View style={styles.emergencyHeader}>
          <AlertTriangle color="#FF6B6B" size={24} />
          <Text style={[styles.emergencyTitle, isPwdMode && styles.largeText]}>
            Emergency Support
          </Text>
        </View>
        <Text style={[styles.emergencyText, isPwdMode && styles.mediumText]}>
          For immediate assistance during rides
        </Text>
        <TouchableOpacity style={styles.emergencyButton}>
          <Phone color="#FFFFFF" size={20} />
          <Text style={[styles.emergencyButtonText, isPwdMode && styles.mediumText]}>
            Call Emergency: 1800-XXX-XXXX
          </Text>
        </TouchableOpacity>
      </View>

      {/* Quick Actions */}
      <View style={styles.quickActions}>
        <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
          Quick Actions
        </Text>
        <View style={styles.actionGrid}>
          <TouchableOpacity style={[styles.actionCard, isPwdMode && styles.largeActionCard]}>
            <Phone color="#00B8F1" size={isPwdMode ? 28 : 24} />
            <Text style={[styles.actionText, isPwdMode && styles.mediumText]}>
              Call Support
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionCard, isPwdMode && styles.largeActionCard]}>
            <MessageCircle color="#00B8F1" size={isPwdMode ? 28 : 24} />
            <Text style={[styles.actionText, isPwdMode && styles.mediumText]}>
              Live Chat
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionCard, isPwdMode && styles.largeActionCard]}>
            <Mail color="#00B8F1" size={isPwdMode ? 28 : 24} />
            <Text style={[styles.actionText, isPwdMode && styles.mediumText]}>
              Email Us
            </Text>
          </TouchableOpacity>
          {isPwdMode && (
            <TouchableOpacity style={[styles.actionCard, styles.accessibilityAction]}>
              <Mic color="#002B5B" size={28} />
              <Text style={[styles.actionText, styles.mediumText]}>
                Voice Support
              </Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Support Categories */}
      <View style={styles.categoriesSection}>
        <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
          What can we help you with?
        </Text>
        <View style={styles.categoriesGrid}>
          {supportCategories.map((category) => (
            <TouchableOpacity
              key={category.id}
              style={[
                styles.categoryCard,
                isPwdMode && styles.largeCategoryCard,
                selectedCategory === category.id && styles.selectedCategory
              ]}
              onPress={() => setSelectedCategory(category.id)}
            >
              <Text style={styles.categoryIcon}>{category.icon}</Text>
              <Text style={[styles.categoryTitle, isPwdMode && styles.mediumText]}>
                {category.title}
              </Text>
              <Text style={[styles.categoryDescription, isPwdMode && styles.smallMediumText]}>
                {category.description}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Message Input */}
      {selectedCategory && (
        <View style={styles.messageSection}>
          <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
            Describe your issue
          </Text>
          <View style={styles.messageInputContainer}>
            <TextInput
              style={[styles.messageInput, isPwdMode && styles.largeMessageInput]}
              placeholder="Type your message here..."
              placeholderTextColor="#999999"
              value={message}
              onChangeText={setMessage}
              multiline
              numberOfLines={4}
              accessibilityLabel="Message input"
              accessibilityHint="Describe your issue in detail"
            />
            {isPwdMode && (
              <TouchableOpacity style={styles.voiceInputButton}>
                <Mic color="#002B5B" size={24} />
              </TouchableOpacity>
            )}
          </View>
          <TouchableOpacity 
            style={[styles.sendButton, isPwdMode && styles.largeSendButton]}
            onPress={handleSendMessage}
          >
            <Send color="#FFFFFF" size={20} />
            <Text style={[styles.sendButtonText, isPwdMode && styles.mediumText]}>
              Send Message
            </Text>
          </TouchableOpacity>
        </View>
      )}

      {/* FAQ Section */}
      <View style={styles.faqSection}>
        <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
          Frequently Asked Questions
        </Text>
        {faqItems.map((faq, index) => (
          <View key={index} style={[styles.faqCard, isPwdMode && styles.largeFaqCard]}>
            <TouchableOpacity
              style={styles.faqQuestion}
              onPress={() => setExpandedFaq(expandedFaq === index ? null : index)}
            >
              <HelpCircle color="#00B8F1" size={20} />
              <Text style={[styles.faqQuestionText, isPwdMode && styles.mediumText]}>
                {faq.question}
              </Text>
            </TouchableOpacity>
            {expandedFaq === index && (
              <Text style={[styles.faqAnswer, isPwdMode && styles.mediumText]}>
                {faq.answer}
              </Text>
            )}
          </View>
        ))}
      </View>

      {/* Accessibility Help */}
      {isPwdMode && (
        <View style={styles.accessibilityHelp}>
          <Text style={[styles.sectionTitle, styles.largeText]}>
            Accessibility Features
          </Text>
          <View style={styles.accessibilityCard}>
            <Text style={[styles.accessibilityText, styles.mediumText]}>
              🔊 Voice Commands: Say "Hey Rapido" to activate voice control
            </Text>
            <Text style={[styles.accessibilityText, styles.mediumText]}>
              👁️ High Contrast: Available in Settings > Accessibility
            </Text>
            <Text style={[styles.accessibilityText, styles.mediumText]}>
              📞 Driver Assistance: Drivers will call before pickup
            </Text>
            <Text style={[styles.accessibilityText, styles.mediumText]}>
              🦯 Screen Reader: Compatible with TalkBack and VoiceOver
            </Text>
          </View>
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    paddingTop: 60,
  },
  header: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#002B5B',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
  },
  largeText: {
    fontSize: 24,
  },
  mediumText: {
    fontSize: 18,
  },
  smallMediumText: {
    fontSize: 16,
  },
  emergencyCard: {
    backgroundColor: '#FFF5F5',
    marginHorizontal: 20,
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    borderWidth: 2,
    borderColor: '#FF6B6B',
  },
  largeEmergencyCard: {
    padding: 20,
  },
  emergencyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  emergencyTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: '#FF6B6B',
    marginLeft: 8,
  },
  emergencyText: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
    marginBottom: 12,
  },
  emergencyButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FF6B6B',
    paddingVertical: 12,
    borderRadius: 8,
    gap: 8,
  },
  emergencyButtonText: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
  },
  quickActions: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: '#002B5B',
    marginBottom: 16,
  },
  actionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  actionCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  largeActionCard: {
    padding: 20,
  },
  accessibilityAction: {
    borderWidth: 2,
    borderColor: '#00B8F1',
  },
  actionText: {
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
    color: '#333333',
    marginTop: 8,
    textAlign: 'center',
  },
  categoriesSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  categoryCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  largeCategoryCard: {
    padding: 20,
  },
  selectedCategory: {
    borderWidth: 2,
    borderColor: '#00B8F1',
    backgroundColor: '#E8F4FD',
  },
  categoryIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  categoryTitle: {
    fontSize: 14,
    fontFamily: 'Poppins-SemiBold',
    color: '#333333',
    marginBottom: 4,
    textAlign: 'center',
  },
  categoryDescription: {
    fontSize: 12,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
    textAlign: 'center',
  },
  messageSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  messageInputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  messageInput: {
    flex: 1,
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#333333',
    textAlignVertical: 'top',
  },
  largeMessageInput: {
    fontSize: 18,
  },
  voiceInputButton: {
    marginLeft: 12,
    padding: 8,
  },
  sendButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#00B8F1',
    paddingVertical: 12,
    borderRadius: 8,
    gap: 8,
  },
  largeSendButton: {
    paddingVertical: 16,
  },
  sendButtonText: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
  },
  faqSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  faqCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  largeFaqCard: {
    marginBottom: 12,
  },
  faqQuestion: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  faqQuestionText: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    color: '#333333',
    marginLeft: 12,
    flex: 1,
  },
  faqAnswer: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
    paddingHorizontal: 48,
    paddingBottom: 16,
    lineHeight: 20,
  },
  accessibilityHelp: {
    paddingHorizontal: 20,
    marginBottom: 40,
  },
  accessibilityCard: {
    backgroundColor: '#E8F4FD',
    borderRadius: 12,
    padding: 16,
    borderWidth: 2,
    borderColor: '#00B8F1',
  },
  accessibilityText: {
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#002B5B',
    marginBottom: 12,
    lineHeight: 22,
  },
});