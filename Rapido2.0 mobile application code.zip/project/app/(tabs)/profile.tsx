import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Switch, Image } from 'react-native';
import { User, Settings, Bell, Shield, CircleHelp as HelpCircle, LogOut, CreditCard as Edit, Star, Armchair as Wheelchair, Volume2 } from 'lucide-react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { router } from 'expo-router';

export default function ProfileScreen() {
  const [userRole, setUserRole] = useState('regular');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [accessibilityMode, setAccessibilityMode] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [locationSharing, setLocationSharing] = useState(true);

  useEffect(() => {
    const getUserData = async () => {
      const role = await AsyncStorage.getItem('userRole');
      const phone = await AsyncStorage.getItem('phoneNumber');
      if (role) setUserRole(role);
      if (phone) setPhoneNumber(phone);
      if (role === 'pwd') setAccessibilityMode(true);
    };
    getUserData();
  }, []);

  const isPwdMode = userRole === 'pwd';
  const isDriver = userRole === 'driver';

  const handleLogout = async () => {
    await AsyncStorage.clear();
    router.replace('/');
  };

  const toggleAccessibilityMode = async (value: boolean) => {
    setAccessibilityMode(value);
    const newRole = value ? 'pwd' : 'regular';
    setUserRole(newRole);
    await AsyncStorage.setItem('userRole', newRole);
  };

  const profileStats = isDriver ? [
    { label: 'Total Trips', value: '1,234', icon: '🚗' },
    { label: 'Rating', value: '4.8', icon: '⭐' },
    { label: 'Years Active', value: '3', icon: '📅' },
  ] : [
    { label: 'Rides Taken', value: '156', icon: '🚗' },
    { label: 'Rating Given', value: '4.9', icon: '⭐' },
    { label: 'Member Since', value: '2022', icon: '📅' },
  ];

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.profileSection}>
          <Image 
            source={{ uri: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=2' }}
            style={styles.profileImage}
          />
          <View style={styles.profileInfo}>
            <Text style={[styles.userName, isPwdMode && styles.largeText]}>
              {isDriver ? 'Rajesh Kumar' : 'John Doe'}
            </Text>
            <Text style={[styles.userPhone, isPwdMode && styles.mediumText]}>
              {phoneNumber || '+91 98765 43210'}
            </Text>
            <View style={styles.userBadge}>
              <Text style={styles.badgeText}>
                {isPwdMode ? '♿ Accessibility User' : isDriver ? '🚗 Verified Driver' : '✅ Verified User'}
              </Text>
            </View>
          </View>
          <TouchableOpacity style={styles.editButton}>
            <Edit color="#00B8F1" size={20} />
          </TouchableOpacity>
        </View>

        <View style={styles.statsContainer}>
          {profileStats.map((stat, index) => (
            <View key={index} style={[styles.statCard, isPwdMode && styles.largeStatCard]}>
              <Text style={styles.statIcon}>{stat.icon}</Text>
              <Text style={[styles.statValue, isPwdMode && styles.mediumText]}>
                {stat.value}
              </Text>
              <Text style={[styles.statLabel, isPwdMode && styles.smallMediumText]}>
                {stat.label}
              </Text>
            </View>
          ))}
        </View>
      </View>

      {/* Accessibility Settings */}
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
          Accessibility
        </Text>
        
        <View style={[styles.settingItem, isPwdMode && styles.largeSettingItem]}>
          <View style={styles.settingLeft}>
            <Wheelchair color="#00B8F1" size={isPwdMode ? 28 : 24} />
            <View style={styles.settingInfo}>
              <Text style={[styles.settingTitle, isPwdMode && styles.mediumText]}>
                Accessibility Mode
              </Text>
              <Text style={[styles.settingDescription, isPwdMode && styles.smallMediumText]}>
                Enhanced features for accessibility
              </Text>
            </View>
          </View>
          <Switch
            value={accessibilityMode}
            onValueChange={toggleAccessibilityMode}
            trackColor={{ false: '#E5E5E5', true: '#00B8F1' }}
            thumbColor={accessibilityMode ? '#FFFFFF' : '#FFFFFF'}
          />
        </View>

        {isPwdMode && (
          <>
            <TouchableOpacity style={[styles.settingItem, styles.largeSettingItem]}>
              <View style={styles.settingLeft}>
                <Volume2 color="#00B8F1" size={28} />
                <View style={styles.settingInfo}>
                  <Text style={[styles.settingTitle, styles.mediumText]}>
                    Voice Settings
                  </Text>
                  <Text style={[styles.settingDescription, styles.smallMediumText]}>
                    Configure voice commands and audio
                  </Text>
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={[styles.settingItem, styles.largeSettingItem]}>
              <View style={styles.settingLeft}>
                <Text style={styles.settingIcon}>🔍</Text>
                <View style={styles.settingInfo}>
                  <Text style={[styles.settingTitle, styles.mediumText]}>
                    Display Settings
                  </Text>
                  <Text style={[styles.settingDescription, styles.smallMediumText]}>
                    High contrast, font size, and more
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          </>
        )}
      </View>

      {/* General Settings */}
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
          Settings
        </Text>

        <View style={[styles.settingItem, isPwdMode && styles.largeSettingItem]}>
          <View style={styles.settingLeft}>
            <Bell color="#666666" size={isPwdMode ? 28 : 24} />
            <View style={styles.settingInfo}>
              <Text style={[styles.settingTitle, isPwdMode && styles.mediumText]}>
                Notifications
              </Text>
              <Text style={[styles.settingDescription, isPwdMode && styles.smallMediumText]}>
                Ride updates and promotions
              </Text>
            </View>
          </View>
          <Switch
            value={notifications}
            onValueChange={setNotifications}
            trackColor={{ false: '#E5E5E5', true: '#00B8F1' }}
            thumbColor={notifications ? '#FFFFFF' : '#FFFFFF'}
          />
        </View>

        <View style={[styles.settingItem, isPwdMode && styles.largeSettingItem]}>
          <View style={styles.settingLeft}>
            <Shield color="#666666" size={isPwdMode ? 28 : 24} />
            <View style={styles.settingInfo}>
              <Text style={[styles.settingTitle, isPwdMode && styles.mediumText]}>
                Location Sharing
              </Text>
              <Text style={[styles.settingDescription, isPwdMode && styles.smallMediumText]}>
                Share location with emergency contacts
              </Text>
            </View>
          </View>
          <Switch
            value={locationSharing}
            onValueChange={setLocationSharing}
            trackColor={{ false: '#E5E5E5', true: '#00B8F1' }}
            thumbColor={locationSharing ? '#FFFFFF' : '#FFFFFF'}
          />
        </View>

        <TouchableOpacity style={[styles.settingItem, isPwdMode && styles.largeSettingItem]}>
          <View style={styles.settingLeft}>
            <Settings color="#666666" size={isPwdMode ? 28 : 24} />
            <View style={styles.settingInfo}>
              <Text style={[styles.settingTitle, isPwdMode && styles.mediumText]}>
                App Settings
              </Text>
              <Text style={[styles.settingDescription, isPwdMode && styles.smallMediumText]}>
                Language, theme, and preferences
              </Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>

      {/* Driver Specific Settings */}
      {isDriver && (
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
            Driver Settings
          </Text>

          <TouchableOpacity style={[styles.settingItem, isPwdMode && styles.largeSettingItem]}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>📄</Text>
              <View style={styles.settingInfo}>
                <Text style={[styles.settingTitle, isPwdMode && styles.mediumText]}>
                  Documents
                </Text>
                <Text style={[styles.settingDescription, isPwdMode && styles.smallMediumText]}>
                  Manage your verification documents
                </Text>
              </View>
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.settingItem, isPwdMode && styles.largeSettingItem]}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>💰</Text>
              <View style={styles.settingInfo}>
                <Text style={[styles.settingTitle, isPwdMode && styles.mediumText]}>
                  Earnings
                </Text>
                <Text style={[styles.settingDescription, isPwdMode && styles.smallMediumText]}>
                  View earnings and payment history
                </Text>
              </View>
            </View>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.settingItem, isPwdMode && styles.largeSettingItem]}>
            <View style={styles.settingLeft}>
              <Text style={styles.settingIcon}>🎓</Text>
              <View style={styles.settingInfo}>
                <Text style={[styles.settingTitle, isPwdMode && styles.mediumText]}>
                  Training
                </Text>
                <Text style={[styles.settingDescription, isPwdMode && styles.smallMediumText]}>
                  Complete mandatory training modules
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        </View>
      )}

      {/* Support & Legal */}
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
          Support & Legal
        </Text>

        <TouchableOpacity style={[styles.settingItem, isPwdMode && styles.largeSettingItem]}>
          <View style={styles.settingLeft}>
            <HelpCircle color="#666666" size={isPwdMode ? 28 : 24} />
            <View style={styles.settingInfo}>
              <Text style={[styles.settingTitle, isPwdMode && styles.mediumText]}>
                Help & Support
              </Text>
              <Text style={[styles.settingDescription, isPwdMode && styles.smallMediumText]}>
                Get help with your account
              </Text>
            </View>
          </View>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.settingItem, isPwdMode && styles.largeSettingItem]}>
          <View style={styles.settingLeft}>
            <Text style={styles.settingIcon}>📋</Text>
            <View style={styles.settingInfo}>
              <Text style={[styles.settingTitle, isPwdMode && styles.mediumText]}>
                Terms & Privacy
              </Text>
              <Text style={[styles.settingDescription, isPwdMode && styles.smallMediumText]}>
                Read our terms and privacy policy
              </Text>
            </View>
          </View>
        </TouchableOpacity>

        <TouchableOpacity style={[styles.settingItem, isPwdMode && styles.largeSettingItem]}>
          <View style={styles.settingLeft}>
            <Star color="#666666" size={isPwdMode ? 28 : 24} />
            <View style={styles.settingInfo}>
              <Text style={[styles.settingTitle, isPwdMode && styles.mediumText]}>
                Rate the App
              </Text>
              <Text style={[styles.settingDescription, isPwdMode && styles.smallMediumText]}>
                Help us improve with your feedback
              </Text>
            </View>
          </View>
        </TouchableOpacity>
      </View>

      {/* Logout */}
      <View style={styles.logoutSection}>
        <TouchableOpacity 
          style={[styles.logoutButton, isPwdMode && styles.largeLogoutButton]}
          onPress={handleLogout}
        >
          <LogOut color="#FF6B6B" size={isPwdMode ? 28 : 24} />
          <Text style={[styles.logoutText, isPwdMode && styles.mediumText]}>
            Logout
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    paddingTop: 60,
  },
  header: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 20,
    paddingVertical: 24,
    marginBottom: 16,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginRight: 16,
  },
  profileInfo: {
    flex: 1,
  },
  userName: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    color: '#002B5B',
    marginBottom: 4,
  },
  userPhone: {
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
    marginBottom: 8,
  },
  userBadge: {
    backgroundColor: '#E8F4FD',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  badgeText: {
    fontSize: 12,
    fontFamily: 'Poppins-Medium',
    color: '#00B8F1',
  },
  editButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F0F0F0',
    alignItems: 'center',
    justifyContent: 'center',
  },
  statsContainer: {
    flexDirection: 'row',
    gap: 16,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
  },
  largeStatCard: {
    padding: 20,
  },
  statIcon: {
    fontSize: 24,
    marginBottom: 8,
  },
  statValue: {
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    color: '#002B5B',
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
    textAlign: 'center',
  },
  largeText: {
    fontSize: 20,
  },
  mediumText: {
    fontSize: 18,
  },
  smallMediumText: {
    fontSize: 16,
  },
  section: {
    backgroundColor: '#FFFFFF',
    marginBottom: 16,
    paddingVertical: 8,
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: '#002B5B',
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#F0F0F0',
  },
  largeSettingItem: {
    paddingVertical: 20,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    fontSize: 24,
    marginRight: 16,
  },
  settingInfo: {
    flex: 1,
    marginLeft: 16,
  },
  settingTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    color: '#333333',
    marginBottom: 4,
  },
  settingDescription: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
  },
  logoutSection: {
    paddingHorizontal: 20,
    paddingVertical: 24,
  },
  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingVertical: 16,
    borderWidth: 2,
    borderColor: '#FF6B6B',
    gap: 12,
  },
  largeLogoutButton: {
    paddingVertical: 20,
  },
  logoutText: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#FF6B6B',
  },
});