import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, Linking } from 'react-native';
import { Shield, Phone, MapPin, Users, TriangleAlert as AlertTriangle, Eye, Share2 } from 'lucide-react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Location from 'expo-location';

const emergencyContacts = [
  { name: 'Police', number: '100', icon: '🚔' },
  { name: 'Ambulance', number: '108', icon: '🚑' },
  { name: 'Fire Brigade', number: '101', icon: '🚒' },
  { name: 'Women Helpline', number: '1091', icon: '👩' },
];

const safetyFeatures = [
  {
    title: 'Live Location Sharing',
    description: 'Share your ride with trusted contacts',
    icon: '📍',
    enabled: true,
  },
  {
    title: 'Driver Verification',
    description: 'All drivers are background verified',
    icon: '✅',
    enabled: true,
  },
  {
    title: 'In-App Emergency',
    description: 'Quick access to emergency services',
    icon: '🆘',
    enabled: true,
  },
  {
    title: 'Ride Monitoring',
    description: '24/7 ride tracking and support',
    icon: '👁️',
    enabled: true,
  },
];

export default function SafetyScreen() {
  const [userRole, setUserRole] = useState('regular');
  const [currentLocation, setCurrentLocation] = useState<any>(null);
  const [emergencyMode, setEmergencyMode] = useState(false);

  useEffect(() => {
    const getUserRole = async () => {
      const role = await AsyncStorage.getItem('userRole');
      if (role) setUserRole(role);
    };
    getUserRole();
    getCurrentLocation();
  }, []);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status === 'granted') {
        const location = await Location.getCurrentPositionAsync({});
        setCurrentLocation(location);
      }
    } catch (error) {
      console.log('Error getting location:', error);
    }
  };

  const isPwdMode = userRole === 'pwd';

  const handleSOS = () => {
    Alert.alert(
      'Emergency SOS',
      'This will immediately alert emergency services and your emergency contacts. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'ACTIVATE SOS',
          style: 'destructive',
          onPress: activateSOS,
        },
      ]
    );
  };

  const activateSOS = () => {
    setEmergencyMode(true);
    // In a real app, this would:
    // 1. Send location to emergency services
    // 2. Alert emergency contacts
    // 3. Notify Rapido safety team
    // 4. Start recording audio/video if permitted
    
    Alert.alert(
      'SOS ACTIVATED',
      'Emergency services and your contacts have been notified. Stay safe!',
      [{ text: 'OK' }]
    );
  };

  const callEmergency = (number: string) => {
    Linking.openURL(`tel:${number}`);
  };

  const shareLocation = () => {
    if (currentLocation) {
      const message = `I'm sharing my live location for safety. Track me here: https://maps.google.com/?q=${currentLocation.coords.latitude},${currentLocation.coords.longitude}`;
      // In a real app, this would open the share dialog
      Alert.alert('Location Shared', 'Your location has been shared with emergency contacts');
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={[styles.title, isPwdMode && styles.largeText]}>
          Safety Center
        </Text>
        <Text style={[styles.subtitle, isPwdMode && styles.mediumText]}>
          Your safety is our priority
        </Text>
      </View>

      {/* SOS Button */}
      <View style={[styles.sosSection, emergencyMode && styles.emergencyActive]}>
        <TouchableOpacity 
          style={[styles.sosButton, isPwdMode && styles.largeSosButton]}
          onPress={handleSOS}
        >
          <Text style={[styles.sosText, isPwdMode && styles.largeSosText]}>
            SOS
          </Text>
          <Text style={[styles.sosSubtext, isPwdMode && styles.mediumText]}>
            Emergency Help
          </Text>
        </TouchableOpacity>
        <Text style={[styles.sosDescription, isPwdMode && styles.mediumText]}>
          Press and hold for 3 seconds to activate emergency alert
        </Text>
      </View>

      {/* Quick Actions */}
      <View style={styles.quickActions}>
        <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
          Quick Safety Actions
        </Text>
        <View style={styles.actionGrid}>
          <TouchableOpacity 
            style={[styles.actionCard, isPwdMode && styles.largeActionCard]}
            onPress={shareLocation}
          >
            <Share2 color="#00B8F1" size={isPwdMode ? 28 : 24} />
            <Text style={[styles.actionText, isPwdMode && styles.mediumText]}>
              Share Location
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionCard, isPwdMode && styles.largeActionCard]}>
            <Eye color="#00B8F1" size={isPwdMode ? 28 : 24} />
            <Text style={[styles.actionText, isPwdMode && styles.mediumText]}>
              Ride Monitoring
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionCard, isPwdMode && styles.largeActionCard]}>
            <Users color="#00B8F1" size={isPwdMode ? 28 : 24} />
            <Text style={[styles.actionText, isPwdMode && styles.mediumText]}>
              Emergency Contacts
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionCard, isPwdMode && styles.largeActionCard]}>
            <Shield color="#00B8F1" size={isPwdMode ? 28 : 24} />
            <Text style={[styles.actionText, isPwdMode && styles.mediumText]}>
              Safety Settings
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Emergency Contacts */}
      <View style={styles.emergencySection}>
        <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
          Emergency Contacts
        </Text>
        <View style={styles.contactsGrid}>
          {emergencyContacts.map((contact, index) => (
            <TouchableOpacity
              key={index}
              style={[styles.contactCard, isPwdMode && styles.largeContactCard]}
              onPress={() => callEmergency(contact.number)}
            >
              <Text style={styles.contactIcon}>{contact.icon}</Text>
              <Text style={[styles.contactName, isPwdMode && styles.mediumText]}>
                {contact.name}
              </Text>
              <Text style={[styles.contactNumber, isPwdMode && styles.mediumText]}>
                {contact.number}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Safety Features */}
      <View style={styles.featuresSection}>
        <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
          Safety Features
        </Text>
        {safetyFeatures.map((feature, index) => (
          <View key={index} style={[styles.featureCard, isPwdMode && styles.largeFeatureCard]}>
            <Text style={styles.featureIcon}>{feature.icon}</Text>
            <View style={styles.featureInfo}>
              <Text style={[styles.featureTitle, isPwdMode && styles.mediumText]}>
                {feature.title}
              </Text>
              <Text style={[styles.featureDescription, isPwdMode && styles.smallMediumText]}>
                {feature.description}
              </Text>
            </View>
            <View style={[styles.featureStatus, feature.enabled && styles.featureEnabled]}>
              <Text style={styles.featureStatusText}>
                {feature.enabled ? '✓' : '○'}
              </Text>
            </View>
          </View>
        ))}
      </View>

      {/* Safety Tips */}
      <View style={styles.tipsSection}>
        <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
          Safety Tips
        </Text>
        <View style={styles.tipCard}>
          <AlertTriangle color="#FF9500" size={20} />
          <View style={styles.tipContent}>
            <Text style={[styles.tipTitle, isPwdMode && styles.mediumText]}>
              Before Your Ride
            </Text>
            <Text style={[styles.tipText, isPwdMode && styles.smallMediumText]}>
              • Verify driver and vehicle details{'\n'}
              • Share trip details with someone{'\n'}
              • Check driver's rating and reviews
            </Text>
          </View>
        </View>

        <View style={styles.tipCard}>
          <Shield color="#00B8F1" size={20} />
          <View style={styles.tipContent}>
            <Text style={[styles.tipTitle, isPwdMode && styles.mediumText]}>
              During Your Ride
            </Text>
            <Text style={[styles.tipText, isPwdMode && styles.smallMediumText]}>
              • Follow the route on the app{'\n'}
              • Keep emergency contacts handy{'\n'}
              • Trust your instincts
            </Text>
          </View>
        </View>

        {isPwdMode && (
          <View style={[styles.tipCard, styles.accessibilityTip]}>
            <Text style={styles.accessibilityIcon}>♿</Text>
            <View style={styles.tipContent}>
              <Text style={[styles.tipTitle, styles.mediumText]}>
                Accessibility Safety
              </Text>
              <Text style={[styles.tipText, styles.smallMediumText]}>
                • Request driver assistance if needed{'\n'}
                • Use voice commands for hands-free operation{'\n'}
                • Enable audio navigation announcements
              </Text>
            </View>
          </View>
        )}
      </View>

      {/* Report Issue */}
      <View style={styles.reportSection}>
        <TouchableOpacity style={[styles.reportButton, isPwdMode && styles.largeReportButton]}>
          <AlertTriangle color="#FFFFFF" size={20} />
          <Text style={[styles.reportButtonText, isPwdMode && styles.mediumText]}>
            Report Safety Issue
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    paddingTop: 60,
  },
  header: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#002B5B',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
  },
  largeText: {
    fontSize: 24,
  },
  mediumText: {
    fontSize: 18,
  },
  smallMediumText: {
    fontSize: 16,
  },
  sosSection: {
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 32,
  },
  emergencyActive: {
    backgroundColor: '#FFE5E5',
    marginHorizontal: -20,
    paddingHorizontal: 20,
    paddingVertical: 20,
    borderRadius: 16,
  },
  sosButton: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#FF6B6B',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    shadowColor: '#FF6B6B',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 8,
  },
  largeSosButton: {
    width: 140,
    height: 140,
    borderRadius: 70,
  },
  sosText: {
    fontSize: 32,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
  },
  largeSosText: {
    fontSize: 36,
  },
  sosSubtext: {
    fontSize: 12,
    fontFamily: 'Poppins-Medium',
    color: '#FFFFFF',
    marginTop: 4,
  },
  sosDescription: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
    textAlign: 'center',
  },
  quickActions: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: '#002B5B',
    marginBottom: 16,
  },
  actionGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  actionCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  largeActionCard: {
    padding: 20,
  },
  actionText: {
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
    color: '#333333',
    marginTop: 8,
    textAlign: 'center',
  },
  emergencySection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  contactsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  contactCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    borderWidth: 1,
    borderColor: '#FF6B6B',
  },
  largeContactCard: {
    padding: 20,
  },
  contactIcon: {
    fontSize: 32,
    marginBottom: 8,
  },
  contactName: {
    fontSize: 14,
    fontFamily: 'Poppins-SemiBold',
    color: '#333333',
    marginBottom: 4,
  },
  contactNumber: {
    fontSize: 16,
    fontFamily: 'Poppins-Bold',
    color: '#FF6B6B',
  },
  featuresSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  featureCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  largeFeatureCard: {
    padding: 20,
  },
  featureIcon: {
    fontSize: 24,
    marginRight: 16,
  },
  featureInfo: {
    flex: 1,
  },
  featureTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#333333',
    marginBottom: 4,
  },
  featureDescription: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
  },
  featureStatus: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#E5E5E5',
    alignItems: 'center',
    justifyContent: 'center',
  },
  featureEnabled: {
    backgroundColor: '#4CAF50',
  },
  featureStatusText: {
    fontSize: 14,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
  },
  tipsSection: {
    paddingHorizontal: 20,
    marginBottom: 24,
  },
  tipCard: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  accessibilityTip: {
    borderWidth: 2,
    borderColor: '#00B8F1',
    backgroundColor: '#E8F4FD',
  },
  accessibilityIcon: {
    fontSize: 20,
    marginRight: 16,
    marginTop: 2,
  },
  tipContent: {
    flex: 1,
  },
  tipTitle: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#333333',
    marginBottom: 8,
  },
  tipText: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
    lineHeight: 20,
  },
  reportSection: {
    paddingHorizontal: 20,
    marginBottom: 40,
  },
  reportButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FF9500',
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
    shadowColor: '#FF9500',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  largeReportButton: {
    paddingVertical: 20,
  },
  reportButtonText: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
  },
});