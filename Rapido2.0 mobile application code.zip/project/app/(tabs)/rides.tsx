import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { MapPin, Clock, Star, Phone, MessageCircle, Navigation } from 'lucide-react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const rideHistory = [
  {
    id: '1',
    date: 'Today, 2:30 PM',
    from: 'Koramangala',
    to: 'Electronic City',
    driver: 'Rajesh Kumar',
    vehicle: 'KA 01 AB 1234',
    rating: 4.8,
    fare: '₹85',
    status: 'completed',
    driverPhoto: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2'
  },
  {
    id: '2',
    date: 'Yesterday, 9:15 AM',
    from: 'HSR Layout',
    to: 'Whitefield',
    driver: 'Suresh Reddy',
    vehicle: 'KA 02 CD 5678',
    rating: 5.0,
    fare: '₹120',
    status: 'completed',
    driverPhoto: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2'
  },
  {
    id: '3',
    date: 'Dec 15, 6:45 PM',
    from: 'MG Road',
    to: 'Airport',
    driver: 'Priya Sharma',
    vehicle: 'KA 03 EF 9012',
    rating: 4.9,
    fare: '₹450',
    status: 'completed',
    driverPhoto: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2'
  }
];

const activeRide = {
  id: 'active1',
  driver: 'Amit Singh',
  vehicle: 'KA 04 GH 3456',
  rating: 4.7,
  eta: '5 mins',
  from: 'Indiranagar',
  to: 'Koramangala',
  driverPhoto: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=100&h=100&dpr=2',
  phone: '+91 98765 43210'
};

export default function RidesScreen() {
  const [userRole, setUserRole] = useState('regular');
  const [hasActiveRide, setHasActiveRide] = useState(true);

  useEffect(() => {
    const getUserRole = async () => {
      const role = await AsyncStorage.getItem('userRole');
      if (role) setUserRole(role);
    };
    getUserRole();
  }, []);

  const isPwdMode = userRole === 'pwd';
  const isDriver = userRole === 'driver';

  if (isDriver) {
    return (
      <ScrollView style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.title}>Trip History</Text>
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>156</Text>
              <Text style={styles.statLabel}>Total Trips</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={styles.statValue}>₹12,450</Text>
              <Text style={styles.statLabel}>This Month</Text>
            </View>
          </View>
        </View>

        {rideHistory.map((ride) => (
          <View key={ride.id} style={styles.rideCard}>
            <View style={styles.rideHeader}>
              <Text style={styles.rideDate}>{ride.date}</Text>
              <Text style={styles.rideFare}>{ride.fare}</Text>
            </View>
            <View style={styles.rideRoute}>
              <MapPin color="#00B8F1" size={16} />
              <Text style={styles.routeText}>{ride.from} → {ride.to}</Text>
            </View>
            <View style={styles.rideFooter}>
              <Text style={styles.passengerName}>Passenger: Anonymous</Text>
              <View style={styles.ratingContainer}>
                <Star color="#FFD700" size={16} fill="#FFD700" />
                <Text style={styles.ratingText}>{ride.rating}</Text>
              </View>
            </View>
          </View>
        ))}
      </ScrollView>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={[styles.title, isPwdMode && styles.largeText]}>
          {hasActiveRide ? 'Current Ride' : 'My Rides'}
        </Text>
      </View>

      {hasActiveRide && (
        <View style={[styles.activeRideCard, isPwdMode && styles.largeActiveRideCard]}>
          <View style={styles.activeRideHeader}>
            <Text style={[styles.activeRideTitle, isPwdMode && styles.largeText]}>
              Ride in Progress
            </Text>
            <View style={styles.etaBadge}>
              <Clock color="#FFFFFF" size={16} />
              <Text style={styles.etaText}>{activeRide.eta}</Text>
            </View>
          </View>

          <View style={styles.driverInfo}>
            <Image source={{ uri: activeRide.driverPhoto }} style={styles.driverPhoto} />
            <View style={styles.driverDetails}>
              <Text style={[styles.driverName, isPwdMode && styles.largeText]}>
                {activeRide.driver}
              </Text>
              <Text style={[styles.vehicleNumber, isPwdMode && styles.mediumText]}>
                {activeRide.vehicle}
              </Text>
              <View style={styles.driverRating}>
                <Star color="#FFD700" size={16} fill="#FFD700" />
                <Text style={styles.ratingText}>{activeRide.rating}</Text>
              </View>
            </View>
          </View>

          <View style={styles.rideRoute}>
            <View style={styles.routePoint}>
              <View style={styles.pickupDot} />
              <Text style={[styles.routeText, isPwdMode && styles.mediumText]}>
                {activeRide.from}
              </Text>
            </View>
            <View style={styles.routeLine} />
            <View style={styles.routePoint}>
              <View style={styles.dropDot} />
              <Text style={[styles.routeText, isPwdMode && styles.mediumText]}>
                {activeRide.to}
              </Text>
            </View>
          </View>

          <View style={styles.actionButtons}>
            <TouchableOpacity style={[styles.actionButton, styles.callButton]}>
              <Phone color="#FFFFFF" size={isPwdMode ? 24 : 20} />
              <Text style={[styles.actionButtonText, isPwdMode && styles.mediumText]}>
                Call Driver
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.actionButton, styles.chatButton]}>
              <MessageCircle color="#FFFFFF" size={isPwdMode ? 24 : 20} />
              <Text style={[styles.actionButtonText, isPwdMode && styles.mediumText]}>
                Chat
              </Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.actionButton, styles.sosButton]}>
              <Text style={[styles.sosText, isPwdMode && styles.mediumText]}>SOS</Text>
            </TouchableOpacity>
          </View>

          {isPwdMode && (
            <View style={styles.accessibilityActions}>
              <TouchableOpacity style={styles.accessibilityButton}>
                <Text style={styles.accessibilityButtonText}>
                  🔊 Announce Location
                </Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.accessibilityButton}>
                <Text style={styles.accessibilityButtonText}>
                  📞 Call for Help
                </Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      )}

      <View style={styles.historySection}>
        <Text style={[styles.sectionTitle, isPwdMode && styles.largeText]}>
          Recent Rides
        </Text>
        
        {rideHistory.map((ride) => (
          <View key={ride.id} style={[styles.rideCard, isPwdMode && styles.largeRideCard]}>
            <View style={styles.rideHeader}>
              <Text style={[styles.rideDate, isPwdMode && styles.mediumText]}>
                {ride.date}
              </Text>
              <Text style={[styles.rideFare, isPwdMode && styles.mediumText]}>
                {ride.fare}
              </Text>
            </View>

            <View style={styles.driverInfo}>
              <Image source={{ uri: ride.driverPhoto }} style={styles.driverPhoto} />
              <View style={styles.driverDetails}>
                <Text style={[styles.driverName, isPwdMode && styles.mediumText]}>
                  {ride.driver}
                </Text>
                <Text style={styles.vehicleNumber}>{ride.vehicle}</Text>
              </View>
              <View style={styles.ratingContainer}>
                <Star color="#FFD700" size={16} fill="#FFD700" />
                <Text style={styles.ratingText}>{ride.rating}</Text>
              </View>
            </View>

            <View style={styles.rideRoute}>
              <MapPin color="#00B8F1" size={16} />
              <Text style={[styles.routeText, isPwdMode && styles.mediumText]}>
                {ride.from} → {ride.to}
              </Text>
            </View>

            <View style={styles.rideActions}>
              <TouchableOpacity style={styles.rebookButton}>
                <Text style={styles.rebookButtonText}>Rebook</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.helpButton}>
                <Text style={styles.helpButtonText}>Help</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8F9FA',
    paddingTop: 60,
  },
  header: {
    paddingHorizontal: 20,
    marginBottom: 20,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#002B5B',
    marginBottom: 8,
  },
  largeText: {
    fontSize: 24,
  },
  mediumText: {
    fontSize: 16,
  },
  statsRow: {
    flexDirection: 'row',
    gap: 20,
  },
  statItem: {
    alignItems: 'center',
  },
  statValue: {
    fontSize: 20,
    fontFamily: 'Poppins-Bold',
    color: '#002B5B',
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
  },
  activeRideCard: {
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    borderLeftWidth: 4,
    borderLeftColor: '#00B8F1',
  },
  largeActiveRideCard: {
    padding: 24,
  },
  activeRideHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  activeRideTitle: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: '#002B5B',
  },
  etaBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#00B8F1',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    gap: 4,
  },
  etaText: {
    fontSize: 12,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
  },
  driverInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  driverPhoto: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 12,
  },
  driverDetails: {
    flex: 1,
  },
  driverName: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#333333',
    marginBottom: 2,
  },
  vehicleNumber: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
    marginBottom: 4,
  },
  driverRating: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  ratingText: {
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
    color: '#333333',
    marginLeft: 4,
  },
  rideRoute: {
    marginBottom: 16,
  },
  routePoint: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  pickupDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#00B8F1',
    marginRight: 12,
  },
  dropDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#FF6B6B',
    marginRight: 12,
  },
  routeLine: {
    width: 2,
    height: 20,
    backgroundColor: '#E5E5E5',
    marginLeft: 4,
    marginBottom: 8,
  },
  routeText: {
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
    color: '#333333',
    marginLeft: 8,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 8,
    gap: 6,
  },
  callButton: {
    backgroundColor: '#00B8F1',
  },
  chatButton: {
    backgroundColor: '#002B5B',
  },
  sosButton: {
    backgroundColor: '#FF6B6B',
    flex: 0.5,
  },
  actionButtonText: {
    fontSize: 14,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
  },
  sosText: {
    fontSize: 14,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
  },
  accessibilityActions: {
    gap: 8,
  },
  accessibilityButton: {
    backgroundColor: '#E8F4FD',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#00B8F1',
  },
  accessibilityButtonText: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    color: '#002B5B',
    textAlign: 'center',
  },
  historySection: {
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: '#002B5B',
    marginBottom: 16,
  },
  rideCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  largeRideCard: {
    padding: 20,
  },
  rideHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  rideDate: {
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
    color: '#666666',
  },
  rideFare: {
    fontSize: 16,
    fontFamily: 'Poppins-Bold',
    color: '#002B5B',
  },
  rideActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 12,
  },
  rebookButton: {
    flex: 1,
    backgroundColor: '#00B8F1',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  rebookButtonText: {
    fontSize: 14,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
  },
  helpButton: {
    flex: 1,
    backgroundColor: '#F0F0F0',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
  },
  helpButtonText: {
    fontSize: 14,
    fontFamily: 'Poppins-SemiBold',
    color: '#666666',
  },
  passengerName: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
  },
  rideFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
});