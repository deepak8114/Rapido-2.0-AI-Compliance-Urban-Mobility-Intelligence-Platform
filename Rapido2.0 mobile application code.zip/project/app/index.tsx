import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, Dimensions } from 'react-native';
import { router } from 'expo-router';
import { User, Armchair as Wheelchair, Car, Mic } from 'lucide-react-native';
import * as Speech from 'expo-speech';
import { LinearGradient } from 'expo-linear-gradient';

const { width, height } = Dimensions.get('window');

const languages = [
  { code: 'en', name: 'English', voice: 'Welcome to Rapido 2.0. Who\'s using the app today?' },
  { code: 'hi', name: 'हिंदी', voice: 'रैपिडो 2.0 में आपका स्वागत है। आज कौन ऐप का उपयोग कर रहा है?' },
  { code: 'ta', name: 'தமிழ்', voice: 'ராபிடோ 2.0 க்கு வரவேற்கிறோம். இன்று யார் ஆப்பைப் பயன்படுத்துகிறார்கள்?' },
  { code: 'te', name: 'తెలుగు', voice: 'రాపిడో 2.0కి స్వాగతం. ఈరోజు యాప్‌ను ఎవరు ఉపయోగిస్తున్నారు?' },
  { code: 'kn', name: 'ಕನ್ನಡ', voice: 'ರಾಪಿಡೋ 2.0 ಗೆ ಸ್ವಾಗತ. ಇಂದು ಯಾರು ಆ್ಯಪ್ ಬಳಸುತ್ತಿದ್ದಾರೆ?' }
];

export default function WelcomeScreen() {
  const [selectedLanguage, setSelectedLanguage] = useState(languages[0]);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    // Auto-play welcome message after 1 second
    const timer = setTimeout(() => {
      playVoicePrompt();
    }, 1000);

    return () => clearTimeout(timer);
  }, [selectedLanguage]);

  const playVoicePrompt = () => {
    if (isPlaying) return;
    
    setIsPlaying(true);
    Speech.speak(selectedLanguage.voice, {
      language: selectedLanguage.code,
      onDone: () => setIsPlaying(false),
      onError: () => setIsPlaying(false),
    });
  };

  const handleRoleSelection = (role: string) => {
    router.push({
      pathname: '/login',
      params: { role, language: selectedLanguage.code }
    });
  };

  return (
    <LinearGradient
      colors={['#002B5B', '#00B8F1']}
      style={styles.container}
    >
      <View style={styles.header}>
        <Image 
          source={{ uri: 'https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg?auto=compress&cs=tinysrgb&w=200&h=200&dpr=2' }}
          style={styles.logo}
        />
        <Text style={styles.title}>Rapido 2.0</Text>
        <Text style={styles.subtitle}>Smart. Safe. Accessible.</Text>
      </View>

      <View style={styles.languageContainer}>
        <Text style={styles.languageLabel}>Select Language / भाषा चुनें</Text>
        <View style={styles.languageGrid}>
          {languages.map((lang) => (
            <TouchableOpacity
              key={lang.code}
              style={[
                styles.languageButton,
                selectedLanguage.code === lang.code && styles.selectedLanguage
              ]}
              onPress={() => setSelectedLanguage(lang)}
            >
              <Text style={[
                styles.languageText,
                selectedLanguage.code === lang.code && styles.selectedLanguageText
              ]}>
                {lang.name}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <TouchableOpacity 
        style={styles.voiceButton}
        onPress={playVoicePrompt}
        disabled={isPlaying}
      >
        <Mic color={isPlaying ? "#00B8F1" : "#FFFFFF"} size={24} />
        <Text style={styles.voiceButtonText}>
          {isPlaying ? 'Playing...' : 'Tap to hear prompt'}
        </Text>
      </TouchableOpacity>

      <View style={styles.roleContainer}>
        <Text style={styles.roleTitle}>Who's using the app today?</Text>
        
        <TouchableOpacity 
          style={styles.roleButton}
          onPress={() => handleRoleSelection('regular')}
        >
          <User color="#002B5B" size={32} />
          <Text style={styles.roleButtonText}>Regular User</Text>
          <Text style={styles.roleButtonSubtext}>Book rides quickly</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={[styles.roleButton, styles.pwdButton]}
          onPress={() => handleRoleSelection('pwd')}
        >
          <Wheelchair color="#002B5B" size={32} />
          <Text style={styles.roleButtonText}>Person with Disability</Text>
          <Text style={styles.roleButtonSubtext}>Accessible ride experience</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.roleButton}
          onPress={() => handleRoleSelection('driver')}
        >
          <Car color="#002B5B" size={32} />
          <Text style={styles.roleButtonText}>Driver</Text>
          <Text style={styles.roleButtonSubtext}>Start earning today</Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 60,
  },
  header: {
    alignItems: 'center',
    marginBottom: 30,
  },
  logo: {
    width: 80,
    height: 80,
    borderRadius: 40,
    marginBottom: 16,
  },
  title: {
    fontSize: 32,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#E0F4FF',
  },
  languageContainer: {
    marginBottom: 20,
  },
  languageLabel: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 12,
  },
  languageGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 8,
  },
  languageButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  selectedLanguage: {
    backgroundColor: '#FFFFFF',
  },
  languageText: {
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
    color: '#FFFFFF',
  },
  selectedLanguageText: {
    color: '#002B5B',
  },
  voiceButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 25,
    marginBottom: 30,
    gap: 8,
  },
  voiceButtonText: {
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
    color: '#FFFFFF',
  },
  roleContainer: {
    flex: 1,
  },
  roleTitle: {
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 24,
  },
  roleButton: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
  },
  pwdButton: {
    borderWidth: 2,
    borderColor: '#00B8F1',
  },
  roleButtonText: {
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
    color: '#002B5B',
    marginTop: 12,
    textAlign: 'center',
  },
  roleButtonSubtext: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#666666',
    marginTop: 4,
    textAlign: 'center',
  },
});