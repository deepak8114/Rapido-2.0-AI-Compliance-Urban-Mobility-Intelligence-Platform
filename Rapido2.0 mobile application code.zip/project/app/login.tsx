import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Phone, Eye, EyeOff, ArrowLeft, Mic } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function LoginScreen() {
  const { role, language } = useLocalSearchParams();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otp, setOtp] = useState('');
  const [showOtp, setShowOtp] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const isPwdMode = role === 'pwd';

  const sendOtp = async () => {
    if (phoneNumber.length !== 10) {
      Alert.alert('Error', 'Please enter a valid 10-digit phone number');
      return;
    }

    setIsLoading(true);
    // Simulate OTP sending
    setTimeout(() => {
      setShowOtp(true);
      setIsLoading(false);
      Alert.alert('OTP Sent', 'Please check your SMS for the verification code');
    }, 1500);
  };

  const verifyOtp = async () => {
    if (otp.length !== 6) {
      Alert.alert('Error', 'Please enter a valid 6-digit OTP');
      return;
    }

    setIsLoading(true);
    
    // Store user data
    await AsyncStorage.setItem('userRole', role as string);
    await AsyncStorage.setItem('userLanguage', language as string);
    await AsyncStorage.setItem('phoneNumber', phoneNumber);
    await AsyncStorage.setItem('isLoggedIn', 'true');

    setTimeout(() => {
      setIsLoading(false);
      router.replace('/(tabs)');
    }, 1000);
  };

  const getRoleTitle = () => {
    switch (role) {
      case 'pwd': return 'Accessible Login';
      case 'driver': return 'Driver Login';
      default: return 'User Login';
    }
  };

  return (
    <LinearGradient
      colors={isPwdMode ? ['#002B5B', '#004080'] : ['#002B5B', '#00B8F1']}
      style={styles.container}
    >
      <TouchableOpacity 
        style={styles.backButton}
        onPress={() => router.back()}
      >
        <ArrowLeft color="#FFFFFF" size={24} />
      </TouchableOpacity>

      <View style={styles.header}>
        <Text style={[styles.title, isPwdMode && styles.largeText]}>
          {getRoleTitle()}
        </Text>
        <Text style={[styles.subtitle, isPwdMode && styles.largeText]}>
          {isPwdMode ? 'Accessible and secure login' : 'Quick and secure login'}
        </Text>
      </View>

      <View style={styles.formContainer}>
        {!showOtp ? (
          <>
            <View style={styles.inputContainer}>
              <Phone color="#666666" size={20} />
              <TextInput
                style={[styles.input, isPwdMode && styles.largeInput]}
                placeholder="Enter phone number"
                placeholderTextColor="#999999"
                value={phoneNumber}
                onChangeText={setPhoneNumber}
                keyboardType="phone-pad"
                maxLength={10}
                accessibilityLabel="Phone number input"
                accessibilityHint="Enter your 10-digit phone number"
              />
            </View>

            {isPwdMode && (
              <TouchableOpacity style={styles.voiceInputButton}>
                <Mic color="#002B5B" size={20} />
                <Text style={styles.voiceInputText}>Voice Input</Text>
              </TouchableOpacity>
            )}

            <TouchableOpacity 
              style={[styles.primaryButton, isPwdMode && styles.largePrimaryButton]}
              onPress={sendOtp}
              disabled={isLoading}
            >
              <Text style={[styles.primaryButtonText, isPwdMode && styles.largeButtonText]}>
                {isLoading ? 'Sending...' : 'Send OTP'}
              </Text>
            </TouchableOpacity>
          </>
        ) : (
          <>
            <View style={styles.inputContainer}>
              <TextInput
                style={[styles.input, isPwdMode && styles.largeInput]}
                placeholder="Enter 6-digit OTP"
                placeholderTextColor="#999999"
                value={otp}
                onChangeText={setOtp}
                keyboardType="number-pad"
                maxLength={6}
                accessibilityLabel="OTP input"
                accessibilityHint="Enter the 6-digit verification code"
              />
            </View>

            <TouchableOpacity 
              style={[styles.primaryButton, isPwdMode && styles.largePrimaryButton]}
              onPress={verifyOtp}
              disabled={isLoading}
            >
              <Text style={[styles.primaryButtonText, isPwdMode && styles.largeButtonText]}>
                {isLoading ? 'Verifying...' : 'Verify & Login'}
              </Text>
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.secondaryButton}
              onPress={() => setShowOtp(false)}
            >
              <Text style={styles.secondaryButtonText}>Change Phone Number</Text>
            </TouchableOpacity>
          </>
        )}

        <View style={styles.divider}>
          <View style={styles.dividerLine} />
          <Text style={styles.dividerText}>OR</Text>
          <View style={styles.dividerLine} />
        </View>

        <TouchableOpacity style={styles.socialButton}>
          <Text style={styles.socialButtonText}>Continue with Google</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.socialButton}>
          <Text style={styles.socialButtonText}>Continue with Apple</Text>
        </TouchableOpacity>

        {isPwdMode && (
          <View style={styles.accessibilityInfo}>
            <Text style={[styles.accessibilityText, styles.largeText]}>
              ♿ This app supports screen readers, voice commands, and high contrast mode
            </Text>
          </View>
        )}
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 60,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    fontSize: 28,
    fontFamily: 'Poppins-Bold',
    color: '#FFFFFF',
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#E0F4FF',
    textAlign: 'center',
  },
  largeText: {
    fontSize: 20,
  },
  formContainer: {
    flex: 1,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingHorizontal: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  input: {
    flex: 1,
    paddingVertical: 16,
    paddingLeft: 12,
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    color: '#333333',
  },
  largeInput: {
    fontSize: 18,
    paddingVertical: 20,
  },
  voiceInputButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    paddingVertical: 12,
    marginBottom: 16,
    gap: 8,
  },
  voiceInputText: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    color: '#002B5B',
  },
  primaryButton: {
    backgroundColor: '#00B8F1',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginBottom: 16,
    shadowColor: '#00B8F1',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  largePrimaryButton: {
    paddingVertical: 20,
  },
  primaryButtonText: {
    fontSize: 16,
    fontFamily: 'Poppins-SemiBold',
    color: '#FFFFFF',
  },
  largeButtonText: {
    fontSize: 18,
  },
  secondaryButton: {
    alignItems: 'center',
    paddingVertical: 12,
  },
  secondaryButtonText: {
    fontSize: 14,
    fontFamily: 'Poppins-Medium',
    color: '#E0F4FF',
  },
  divider: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 24,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  dividerText: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#E0F4FF',
    marginHorizontal: 16,
  },
  socialButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  socialButtonText: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
    color: '#FFFFFF',
  },
  accessibilityInfo: {
    marginTop: 20,
    padding: 16,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
  },
  accessibilityText: {
    fontSize: 14,
    fontFamily: 'Poppins-Regular',
    color: '#E0F4FF',
    textAlign: 'center',
    lineHeight: 20,
  },
});